const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

let allCases = []; // initial empty data

// GET CSV for KNIME
app.get('/cases.csv', (req, res) => {
    if (!allCases.length) {
        return res.send('Case Number,Crime Type,...\n'); // empty CSV header
    }

    const headers = [
        'Case Number','Crime Type','Incident Date','Platform',
        'Description','Status','Priority','Submitted At',
        'Updated At','Resolved At','Assigned To',
        'Reporter Name','Reporter Email','Reporter Phone','Anonymous'
    ];

    const rows = allCases.map(c => [
        c.caseNumber || '',
        c.crimeType || '',
        c.incidentDate || '',
        c.platform || '',
        (c.description || '').replace(/[\r\n]+/g,' '),
        c.status || '',
        c.priority || '',
        c.submittedAt || '',
        c.updatedAt || '',
        c.resolvedAt || '',
        c.assignedTo || '',
        c.reporterName || '',
        c.reporterEmail || '',
        c.reporterPhone || '',
        c.anonymous ? 'Yes' : 'No'
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.map(f => `"${f}"`).join(','))].join('\n');

    res.setHeader('Content-Type','text/csv');
    res.send(csvContent);
});

// POST endpoint to update cases from browser
app.post('/update-cases', (req, res) => {
    allCases = req.body; // replace with browser data
    res.json({ message: 'Cases updated successfully', count: allCases.length });
});

app.listen(5500, () => console.log('Server running on http://localhost:5500'));

